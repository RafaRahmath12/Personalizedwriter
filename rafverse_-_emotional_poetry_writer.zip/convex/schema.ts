import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  poems: defineTable({
    userId: v.optional(v.id("users")),
    title: v.string(),
    content: v.string(),
    emotion: v.string(),
    theme: v.string(),
    perspective: v.string(),
    triggerWord: v.optional(v.string()),
    isFavorite: v.optional(v.boolean()),
  }).index("by_user", ["userId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
