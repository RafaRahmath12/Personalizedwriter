import { v } from "convex/values";
import { query, mutation, action } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import OpenAI from "openai";

const openai = new OpenAI({
  baseURL: process.env.CONVEX_OPENAI_BASE_URL,
  apiKey: process.env.CONVEX_OPENAI_API_KEY,
});

export const generatePoem = action({
  args: {
    emotion: v.string(),
    theme: v.string(),
    perspective: v.string(),
    triggerWord: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const prompt = `You are RafVerse, a personalized emotional poetry writer. Write a poem in Hindi but using Roman English (Hinglish) that blends raw human emotion with unfiltered honesty.

Style Guidelines:
- Reflective, direct, and poetic
- Half rooted in reality, half drifting into dreamlike thought
- Use simple words that hit deep, not heavy vocabulary
- Personal tone - like someone whispering truths to themselves at midnight
- Between hope and heartbreak, between faith and fatigue
- Free verse (no rhyme requirement), 8-14 lines
- End with a lingering thought or half-finished feeling

Poem Parameters:
- Emotion: ${args.emotion}
- Theme: ${args.theme}
- Perspective: ${args.perspective}
${args.triggerWord ? `- Revolve around the word: ${args.triggerWord}` : ""}

Write a poem that captures the essence of someone who has lived a little too much and felt even more. Make it feel like midnight confessions, raw and honest.

Return only the poem content, no explanations or titles.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.8,
    });

    const poemContent = response.choices[0].message.content || "";
    
    // Generate a poetic title
    const titlePrompt = `Create a short, poetic title (2-4 words) in Hindi Roman English for this poem about ${args.theme} and ${args.emotion}. Make it evocative and mysterious.`;
    
    const titleResponse = await openai.chat.completions.create({
      model: "gpt-4.1-nano",
      messages: [{ role: "user", content: titlePrompt }],
      temperature: 0.7,
    });

    const title = titleResponse.choices[0].message.content || "Untitled";

    return { content: poemContent, title };
  },
});

export const savePoem = mutation({
  args: {
    title: v.string(),
    content: v.string(),
    emotion: v.string(),
    theme: v.string(),
    perspective: v.string(),
    triggerWord: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    
    return await ctx.db.insert("poems", {
      userId: userId || undefined,
      title: args.title,
      content: args.content,
      emotion: args.emotion,
      theme: args.theme,
      perspective: args.perspective,
      triggerWord: args.triggerWord,
      isFavorite: false,
    });
  },
});

export const getUserPoems = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    
    return await ctx.db
      .query("poems")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
  },
});

export const toggleFavorite = mutation({
  args: { poemId: v.id("poems") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    const poem = await ctx.db.get(args.poemId);
    if (!poem || poem.userId !== userId) {
      throw new Error("Poem not found or unauthorized");
    }
    
    await ctx.db.patch(args.poemId, {
      isFavorite: !poem.isFavorite,
    });
  },
});

export const deletePoem = mutation({
  args: { poemId: v.id("poems") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    
    const poem = await ctx.db.get(args.poemId);
    if (!poem || poem.userId !== userId) {
      throw new Error("Poem not found or unauthorized");
    }
    
    await ctx.db.delete(args.poemId);
  },
});
