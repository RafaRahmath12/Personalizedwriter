import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { PoemGenerator } from "./components/PoemGenerator";
import { PoemLibrary } from "./components/PoemLibrary";
import { useState } from "react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"generate" | "library">("generate");

  return (
    <div className="min-h-screen bg-black relative overflow-hidden">
      {/* Animated stars background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="stars"></div>
        <div className="stars2"></div>
        <div className="stars3"></div>
      </div>
      
      {/* Smokey effect overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/40"></div>
      
      <div className="relative z-10 min-h-screen flex flex-col">
        <header className="sticky top-0 z-20 bg-black/80 backdrop-blur-sm border-b border-yellow-500/20">
          <div className="container mx-auto px-4 h-16 flex justify-between items-center">
            <h1 className="text-2xl font-bold text-yellow-400 tracking-wider">
              RafVerse
            </h1>
            <Authenticated>
              <div className="flex items-center gap-4">
                <nav className="flex gap-4">
                  <button
                    onClick={() => setActiveTab("generate")}
                    className={`px-4 py-2 rounded-lg transition-all ${
                      activeTab === "generate"
                        ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                        : "text-yellow-300/70 hover:text-yellow-400"
                    }`}
                  >
                    Create
                  </button>
                  <button
                    onClick={() => setActiveTab("library")}
                    className={`px-4 py-2 rounded-lg transition-all ${
                      activeTab === "library"
                        ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                        : "text-yellow-300/70 hover:text-yellow-400"
                    }`}
                  >
                    Library
                  </button>
                </nav>
                <SignOutButton />
              </div>
            </Authenticated>
            <Unauthenticated>
              <div className="text-yellow-300/70 text-sm">
                Sign in to create poetry
              </div>
            </Unauthenticated>
          </div>
        </header>

        <main className="flex-1 container mx-auto px-4 py-8">
          <Content activeTab={activeTab} />
        </main>
      </div>
      
      <Toaster 
        theme="dark"
        toastOptions={{
          style: {
            background: 'rgba(0, 0, 0, 0.8)',
            border: '1px solid rgba(234, 179, 8, 0.3)',
            color: '#fbbf24',
          },
        }}
      />
    </div>
  );
}

function Content({ activeTab }: { activeTab: "generate" | "library" }) {
  const loggedInUser = useQuery(api.auth.loggedInUser);

  if (loggedInUser === undefined) {
    return (
      <div className="flex justify-center items-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-2 border-yellow-400 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <Unauthenticated>
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold text-yellow-400 mb-4 tracking-wide">
            RafVerse
          </h2>
          <p className="text-xl text-yellow-300/80 mb-2">
            Personalized Emotional Poetry Writer
          </p>
          <p className="text-yellow-300/60 mb-8">
            Raw emotions, unfiltered honesty, midnight confessions
          </p>
          <div className="max-w-md mx-auto">
            <SignInForm />
          </div>
        </div>
      </Unauthenticated>

      <Authenticated>
        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-yellow-400 mb-2 tracking-wide">
            Welcome back, poet
          </h2>
          <p className="text-yellow-300/70">
            Let your emotions flow into words that matter
          </p>
        </div>

        {activeTab === "generate" ? <PoemGenerator /> : <PoemLibrary />}
      </Authenticated>
    </div>
  );
}
