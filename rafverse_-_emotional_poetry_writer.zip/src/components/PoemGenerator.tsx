import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

const emotions = [
  "sad", "happy", "motivated", "hopeful", "strong", "in love", 
  "confused", "nostalgic", "angry", "peaceful", "anxious", "free"
];

const themes = [
  "love", "self-discovery", "nostalgia", "chaos", "healing", 
  "motivation", "experiences", "dreams", "loss", "growth", "identity", "freedom"
];

const perspectives = [
  "first person", "second person", "third person"
];

export function PoemGenerator() {
  const [emotion, setEmotion] = useState("");
  const [theme, setTheme] = useState("");
  const [perspective, setPerspective] = useState("");
  const [triggerWord, setTriggerWord] = useState("");
  const [generatedPoem, setGeneratedPoem] = useState<{title: string, content: string} | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  const generatePoem = useAction(api.poems.generatePoem);
  const savePoem = useMutation(api.poems.savePoem);

  const handleGenerate = async () => {
    if (!emotion || !theme || !perspective) {
      toast.error("Please fill in emotion, theme, and perspective");
      return;
    }

    setIsGenerating(true);
    try {
      const result = await generatePoem({
        emotion,
        theme,
        perspective,
        triggerWord: triggerWord || undefined,
      });
      setGeneratedPoem(result);
      toast.success("Poem generated successfully!");
    } catch (error) {
      toast.error("Failed to generate poem. Please try again.");
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = async () => {
    if (!generatedPoem) return;

    try {
      await savePoem({
        title: generatedPoem.title,
        content: generatedPoem.content,
        emotion,
        theme,
        perspective,
        triggerWord: triggerWord || undefined,
      });
      toast.success("Poem saved to your library!");
    } catch (error) {
      toast.error("Failed to save poem");
      console.error(error);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-8">
      {/* Input Form */}
      <div className="space-y-6">
        <div className="bg-black/40 backdrop-blur-sm border border-yellow-500/20 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-yellow-400 mb-4">
            Craft Your Emotions
          </h3>
          
          <div className="space-y-4">
            <div>
              <label className="block text-yellow-300/80 text-sm font-medium mb-2">
                Emotion *
              </label>
              <select
                value={emotion}
                onChange={(e) => setEmotion(e.target.value)}
                className="w-full bg-black/60 border border-yellow-500/30 rounded-lg px-4 py-3 text-yellow-300 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 outline-none transition-all"
              >
                <option value="">Select your emotion...</option>
                {emotions.map((e) => (
                  <option key={e} value={e}>{e}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-yellow-300/80 text-sm font-medium mb-2">
                Theme *
              </label>
              <select
                value={theme}
                onChange={(e) => setTheme(e.target.value)}
                className="w-full bg-black/60 border border-yellow-500/30 rounded-lg px-4 py-3 text-yellow-300 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 outline-none transition-all"
              >
                <option value="">Select your theme...</option>
                {themes.map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-yellow-300/80 text-sm font-medium mb-2">
                Perspective *
              </label>
              <select
                value={perspective}
                onChange={(e) => setPerspective(e.target.value)}
                className="w-full bg-black/60 border border-yellow-500/30 rounded-lg px-4 py-3 text-yellow-300 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 outline-none transition-all"
              >
                <option value="">Select perspective...</option>
                {perspectives.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-yellow-300/80 text-sm font-medium mb-2">
                Trigger Word (optional)
              </label>
              <input
                type="text"
                value={triggerWord}
                onChange={(e) => setTriggerWord(e.target.value)}
                placeholder="A word to revolve the poem around..."
                className="w-full bg-black/60 border border-yellow-500/30 rounded-lg px-4 py-3 text-yellow-300 placeholder-yellow-300/40 focus:border-yellow-400 focus:ring-1 focus:ring-yellow-400 outline-none transition-all"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isGenerating || !emotion || !theme || !perspective}
              className="w-full bg-gradient-to-r from-yellow-500 to-yellow-600 text-black font-semibold py-3 px-6 rounded-lg hover:from-yellow-400 hover:to-yellow-500 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-yellow-500/25"
            >
              {isGenerating ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-black border-t-transparent"></div>
                  Crafting your poem...
                </div>
              ) : (
                "Generate Poem"
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Generated Poem Display */}
      <div className="space-y-6">
        {generatedPoem && (
          <div className="bg-black/40 backdrop-blur-sm border border-yellow-500/20 rounded-lg p-6">
            <div className="flex justify-between items-start mb-4">
              <h3 className="text-xl font-semibold text-yellow-400">
                {generatedPoem.title}
              </h3>
              <button
                onClick={handleSave}
                className="bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 px-4 py-2 rounded-lg border border-yellow-500/30 transition-all text-sm"
              >
                Save to Library
              </button>
            </div>
            
            <div className="bg-black/60 rounded-lg p-6 border border-yellow-500/10">
              <pre className="text-yellow-300 leading-relaxed whitespace-pre-wrap font-serif text-lg">
                {generatedPoem.content}
              </pre>
            </div>

            <div className="mt-4 flex flex-wrap gap-2 text-xs">
              <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                {emotion}
              </span>
              <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                {theme}
              </span>
              <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                {perspective}
              </span>
              {triggerWord && (
                <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                  "{triggerWord}"
                </span>
              )}
            </div>
          </div>
        )}

        {!generatedPoem && (
          <div className="bg-black/20 backdrop-blur-sm border border-yellow-500/10 rounded-lg p-8 text-center">
            <div className="text-yellow-300/40 text-lg mb-2">
              Your poem will appear here
            </div>
            <div className="text-yellow-300/30 text-sm">
              Fill in the form and click generate to create your personalized poetry
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
