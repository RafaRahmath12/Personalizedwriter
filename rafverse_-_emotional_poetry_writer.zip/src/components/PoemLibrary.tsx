import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useState } from "react";
import { toast } from "sonner";

export function PoemLibrary() {
  const poems = useQuery(api.poems.getUserPoems) || [];
  const toggleFavorite = useMutation(api.poems.toggleFavorite);
  const deletePoem = useMutation(api.poems.deletePoem);
  const [filter, setFilter] = useState<"all" | "favorites">("all");

  const filteredPoems = poems.filter(poem => 
    filter === "all" || (filter === "favorites" && poem.isFavorite)
  );

  const handleToggleFavorite = async (poemId: string) => {
    try {
      await toggleFavorite({ poemId: poemId as any });
    } catch (error) {
      toast.error("Failed to update favorite status");
    }
  };

  const handleDelete = async (poemId: string) => {
    if (!confirm("Are you sure you want to delete this poem?")) return;
    
    try {
      await deletePoem({ poemId: poemId as any });
      toast.success("Poem deleted successfully");
    } catch (error) {
      toast.error("Failed to delete poem");
    }
  };

  if (poems.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="text-yellow-300/40 text-xl mb-4">
          Your poetry library is empty
        </div>
        <div className="text-yellow-300/30">
          Create your first poem to see it here
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-yellow-400">
          Your Poetry Library
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 rounded-lg transition-all ${
              filter === "all"
                ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                : "text-yellow-300/70 hover:text-yellow-400"
            }`}
          >
            All ({poems.length})
          </button>
          <button
            onClick={() => setFilter("favorites")}
            className={`px-4 py-2 rounded-lg transition-all ${
              filter === "favorites"
                ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500/30"
                : "text-yellow-300/70 hover:text-yellow-400"
            }`}
          >
            Favorites ({poems.filter(p => p.isFavorite).length})
          </button>
        </div>
      </div>

      <div className="grid gap-6">
        {filteredPoems.map((poem) => (
          <div
            key={poem._id}
            className="bg-black/40 backdrop-blur-sm border border-yellow-500/20 rounded-lg p-6 hover:border-yellow-500/30 transition-all"
          >
            <div className="flex justify-between items-start mb-4">
              <h4 className="text-xl font-semibold text-yellow-400">
                {poem.title}
              </h4>
              <div className="flex gap-2">
                <button
                  onClick={() => handleToggleFavorite(poem._id)}
                  className={`p-2 rounded-lg transition-all ${
                    poem.isFavorite
                      ? "text-yellow-400 bg-yellow-500/20"
                      : "text-yellow-300/50 hover:text-yellow-400"
                  }`}
                >
                  ★
                </button>
                <button
                  onClick={() => handleDelete(poem._id)}
                  className="p-2 rounded-lg text-red-400/70 hover:text-red-400 hover:bg-red-500/10 transition-all"
                >
                  🗑
                </button>
              </div>
            </div>

            <div className="bg-black/60 rounded-lg p-4 border border-yellow-500/10 mb-4">
              <pre className="text-yellow-300 leading-relaxed whitespace-pre-wrap font-serif">
                {poem.content}
              </pre>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex flex-wrap gap-2 text-xs">
                <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                  {poem.emotion}
                </span>
                <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                  {poem.theme}
                </span>
                <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                  {poem.perspective}
                </span>
                {poem.triggerWord && (
                  <span className="bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded">
                    "{poem.triggerWord}"
                  </span>
                )}
              </div>
              <div className="text-yellow-300/40 text-xs">
                {new Date(poem._creationTime).toLocaleDateString()}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredPoems.length === 0 && filter === "favorites" && (
        <div className="text-center py-8">
          <div className="text-yellow-300/40">
            No favorite poems yet
          </div>
          <div className="text-yellow-300/30 text-sm">
            Star your favorite poems to see them here
          </div>
        </div>
      )}
    </div>
  );
}
